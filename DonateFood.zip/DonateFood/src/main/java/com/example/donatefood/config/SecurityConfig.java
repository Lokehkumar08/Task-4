package com.example.donatefood.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())  // Disable CSRF for development (enable in production)
            .authorizeHttpRequests(authz -> authz
                // Permit access to our custom endpoints
                .requestMatchers(
                    "/restaurant/login",
                    "/restaurant/register",
                    "/restaurant/forgot-password",
                    "/admin/login",
                    "/admin/register",
                    "/admin/forgot-password",
                    "/delivery/login",
                    "/delivery/register",
                    "/delivery/forgot-password",
                    "/", "/index"
                ).permitAll()
                // Optionally, you can decide which endpoints need authentication.
                // For now, let's permit all:
                .anyRequest().permitAll()
            )
            .formLogin(form -> form
                // Use your custom login page
                .loginPage("/restaurant/login")
                // Set the URL that processes the login form
                .loginProcessingUrl("/restaurant/login")
                // Redirect to restaurant home after successful login
                .defaultSuccessUrl("/restaurant/home", true)
                .permitAll()
            )
            .logout(logout -> logout.permitAll());
        return http.build();
    }
}
