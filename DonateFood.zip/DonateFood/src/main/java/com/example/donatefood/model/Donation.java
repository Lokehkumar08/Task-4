package com.example.donatefood.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "donations")
public class Donation {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String foodName;
    
    @Enumerated(EnumType.STRING)
    private MealType mealType;
    
    @Enumerated(EnumType.STRING)
    private Category category;
    
    private Integer quantity;
    private String contactName;
    private String contactPhone;
    private String district;
    private String address;
    
    @Enumerated(EnumType.STRING)
    private DonationStatus donationStatus = DonationStatus.PENDING;
    
    @ManyToOne
    @JoinColumn(name = "restaurant_manager_id", nullable = false)
    private User restaurantManager;
    
    @ManyToOne
    @JoinColumn(name = "assigned_delivery_person_id")
    private User assignedDeliveryPerson;
    
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    // Getters and Setters...
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getFoodName() { return foodName; }
    public void setFoodName(String foodName) { this.foodName = foodName; }
    
    public MealType getMealType() { return mealType; }
    public void setMealType(MealType mealType) { this.mealType = mealType; }
    
    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
    
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    
    public String getContactName() { return contactName; }
    public void setContactName(String contactName) { this.contactName = contactName; }
    
    public String getContactPhone() { return contactPhone; }
    public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }
    
    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public DonationStatus getDonationStatus() { return donationStatus; }
    public void setDonationStatus(DonationStatus donationStatus) { this.donationStatus = donationStatus; }
    
    public User getRestaurantManager() { return restaurantManager; }
    public void setRestaurantManager(User restaurantManager) { this.restaurantManager = restaurantManager; }
    
    public User getAssignedDeliveryPerson() { return assignedDeliveryPerson; }
    public void setAssignedDeliveryPerson(User assignedDeliveryPerson) { this.assignedDeliveryPerson = assignedDeliveryPerson; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    
    public enum MealType {
        VEG,
        NON_VEG
    }
    public enum Category {
        RAW, COOKED, PACKED
    }
    public enum DonationStatus {
        PENDING, ASSIGNED, COMPLETED
    }
}
