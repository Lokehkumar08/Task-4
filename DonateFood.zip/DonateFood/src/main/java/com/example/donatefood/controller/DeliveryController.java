package com.example.donatefood.controller;

import com.example.donatefood.model.Donation;
import com.example.donatefood.model.User;
import com.example.donatefood.service.DonationService;
import com.example.donatefood.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/delivery")
public class DeliveryController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private DonationService donationService;
    
    // Display delivery person registration page
    @GetMapping("/register")
    public String showRegisterPage() {
        return "delivery/register";
    }
    
    // Process registration
    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model) {
        user.setRole(User.Role.DELIVERY);
        userService.registerUser(user);
        model.addAttribute("message", "Delivery person registered successfully!");
        return "delivery/login";
    }
    
    // Display delivery person login page
    @GetMapping("/login")
    public String showLoginPage() {
        return "delivery/login";
    }
    
    // Process login (simplified)
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        model.addAttribute("username", username);
        return "delivery/home";
    }
    
    // Display delivery home page with "Take Order" button
    @GetMapping("/home")
    public String deliveryHome() {
        return "delivery/home";
    }
    
    // Process "Take Order" action
    @PostMapping("/take-order")
    public String takeOrder(@RequestParam Long donationId, Model model) {
        model.addAttribute("message", "Order " + donationId + " taken successfully!");
        return "redirect:/delivery/myOrders";
    }
    
    // Display My Orders page
    @GetMapping("/myOrders")
    public String myOrders(Model model) {
        model.addAttribute("orders", donationService.getAllDonations());
        return "delivery/myOrders";
    }
    
    // Display update location page (simulate live location update)
    @GetMapping("/update-location")
    public String showUpdateLocationPage() {
        return "delivery/updateLocation";
    }
    
    // Process location update
    @PostMapping("/update-location")
    public String updateLocation(@RequestParam Long userId,
                                 @RequestParam Double latitude,
                                 @RequestParam Double longitude,
                                 Model model) {
        model.addAttribute("message", "Location updated successfully!");
        return "delivery/home";
    }
}
