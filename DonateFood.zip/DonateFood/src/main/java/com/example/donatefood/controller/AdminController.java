package com.example.donatefood.controller;

import com.example.donatefood.model.Donation;
import com.example.donatefood.model.User;
import com.example.donatefood.service.DonationService;
import com.example.donatefood.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private DonationService donationService;
    
    // Display admin registration page
    @GetMapping("/register")
    public String showRegisterPage() {
        return "admin/register";
    }
    
    // Process admin registration
    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model) {
        user.setRole(User.Role.ADMIN);
        userService.registerUser(user);
        model.addAttribute("message", "Admin registered successfully!");
        return "admin/login";
    }
    
    // Display admin login page
    @GetMapping("/login")
    public String showLoginPage() {
        return "admin/login";
    }
    
    // Process admin login (simplified)
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        model.addAttribute("username", username);
        return "admin/dashboard";
    }
    
    // Display forgot password page
    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "admin/forgotPassword";
    }
    
    // Process forgot password
    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestParam String email, Model model) {
        model.addAttribute("message", "Password reset link sent to " + email);
        return "admin/login";
    }
    
    // Display admin dashboard with summary info
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalUsers", 10); // Dummy data
        model.addAttribute("totalDonations", 20);
        model.addAttribute("recentDonations", donationService.getAllDonations());
        return "admin/dashboard";
    }
    
    // List all donations with option to assign a delivery person
    @GetMapping("/donations")
    public String listDonations(Model model) {
        model.addAttribute("donations", donationService.getAllDonations());
        return "admin/donations";
    }
    
    // Process assignment of a donation to a delivery person
    @PostMapping("/assign")
    public String assignDonation(@RequestParam Long donationId, @RequestParam Long deliveryId, Model model) {
        // Implement logic to update the donation assignment here.
        model.addAttribute("message", "Donation " + donationId + " assigned to delivery person " + deliveryId);
        return "redirect:/admin/donations";
    }
}
