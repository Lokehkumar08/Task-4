package com.example.donatefood.util;

import org.springframework.stereotype.Component;

@Component
public class MailUtil {
    public void sendPasswordResetEmail(String email, String token) {
        // Implement actual email sending logic here.
        System.out.println("Sending password reset email to: " + email + " with token: " + token);
    }
}
