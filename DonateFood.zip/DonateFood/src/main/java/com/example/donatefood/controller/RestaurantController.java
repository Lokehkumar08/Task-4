package com.example.donatefood.controller;

import com.example.donatefood.model.Donation;
import com.example.donatefood.model.User;
import com.example.donatefood.service.DonationService;
import com.example.donatefood.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/restaurant")
public class RestaurantController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private DonationService donationService;
    
    // Display registration page
    @GetMapping("/register")
    public String showRegisterPage() {
        return "restaurant/register";
    }
    
    // Process registration form
    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model) {
        user.setRole(User.Role.RESTAURANT);
        userService.registerUser(user);
        model.addAttribute("message", "Registration successful!");
        return "restaurant/login";
    }
    
    // Display login page
    @GetMapping("/login")
    public String showLoginPage() {
        return "restaurant/login";
    }
    
    // Process login (simplified)
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        // Dummy authentication logic; implement real security as needed.
        model.addAttribute("username", username);
        return "restaurant/home";
    }
    
    // Display forgot password page
    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "restaurant/forgotPassword";
    }
    
    // Process forgot password
    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestParam String email, Model model) {
        // Add token generation and email logic here.
        model.addAttribute("message", "Password reset link sent to " + email);
        return "restaurant/login";
    }
    
    // Display restaurant home page with Donate Food button and quotations
    @GetMapping("/home")
    public String restaurantHome() {
        return "restaurant/home";
    }
    
    // Display donate food form
    @GetMapping("/donate")
    public String showDonateForm() {
        return "restaurant/donate";
    }
    
    // Process donation form
    @PostMapping("/donate")
    public String donateFood(@ModelAttribute Donation donation, Model model) {
        donation.setDonationStatus(Donation.DonationStatus.PENDING);
        // In a real app, set the restaurantManager using the logged-in user.
        donationService.createDonation(donation);
        model.addAttribute("message", "Donation submitted successfully!");
        return "restaurant/home";
    }
}
